import React, { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"

interface ChallengeButtonProps {
  postId: string
}

export function ChallengeButton({ postId }: ChallengeButtonProps) {
  const [isOpen, setIsOpen] = useState(false)
  const [compareType, setCompareType] = useState('')
  const [selectedGraph, setSelectedGraph] = useState('')

  const handleChallenge = () => {
    // Here you would implement the logic to create and share the challenge
    console.log(`Creating challenge for post ${postId}`)
    console.log(`Compare type: ${compareType}`)
    console.log(`Selected graph: ${selectedGraph}`)
    setIsOpen(false)
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline">Challenge</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Create a Challenge</DialogTitle>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label htmlFor="compare-type">What to compare</Label>
            <Select value={compareType} onValueChange={setCompareType}>
              <SelectTrigger id="compare-type">
                <SelectValue placeholder="Select comparison type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="period">Same period</SelectItem>
                <SelectItem value="milestones">Milestones</SelectItem>
                <SelectItem value="whole">Whole journey</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="graph-select">Select your graph to compare</Label>
            <Select value={selectedGraph} onValueChange={setSelectedGraph}>
              <SelectTrigger id="graph-select">
                <SelectValue placeholder="Select a graph" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="graph1">My Fitness Journey</SelectItem>
                <SelectItem value="graph2">Weight Loss Progress</SelectItem>
                <SelectItem value="graph3">Muscle Gain Tracker</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button onClick={handleChallenge}>Create Challenge</Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}

