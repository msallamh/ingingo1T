'use client'

import React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from 'recharts'

interface CigarettesData {
  date: string
  count: number
}

interface CigarettesGraphProps {
  data: CigarettesData[]
}

export function CigarettesGraph({ data }: CigarettesGraphProps) {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Cutting Down Cigarettes</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data}>
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Line key="count" type="monotone" dataKey="count" stroke="#ff7300" />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

