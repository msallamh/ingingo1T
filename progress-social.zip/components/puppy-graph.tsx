'use client'

import React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from 'recharts'

interface PuppyData {
  date: string
  tricks: number
}

interface PuppyGraphProps {
  data: PuppyData[]
}

export function PuppyGraph({ data }: PuppyGraphProps) {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Raising a Puppy</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data}>
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Bar key="tricks" dataKey="tricks" fill="#82ca9d" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

