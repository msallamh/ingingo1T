'use client'

import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

interface UpdateGraphFormProps {
  onSubmit: () => void
}

const SAMPLE_GRAPHS = [
  { id: '1', title: 'Fitness Progress' },
  { id: '2', title: 'Weight Loss Journey' },
  { id: '3', title: 'Productivity Tracking' },
]

export function UpdateGraphForm({ onSubmit }: UpdateGraphFormProps) {
  const [selectedGraph, setSelectedGraph] = useState('')
  const [newValue, setNewValue] = useState('')
  const [date, setDate] = useState('')
  const [description, setDescription] = useState('')
  const [media, setMedia] = useState<string | null>(null)

  const handleMediaUpload = (file: File) => {
    const reader = new FileReader()
    reader.onloadend = () => {
      setMedia(reader.result as string)
    }
    reader.readAsDataURL(file)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send the data to your backend
    console.log('Graph update submitted:', { 
      selectedGraph,
      newValue,
      date,
      description,
      media
    })
    onSubmit()
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6 bg-white p-6 rounded-lg shadow">
      <h2 className="text-2xl font-bold mb-4">Update Existing Graph</h2>
      
      <div>
        <Label htmlFor="graph-select">Select Graph</Label>
        <Select value={selectedGraph} onValueChange={setSelectedGraph}>
          <SelectTrigger id="graph-select">
            <SelectValue placeholder="Select a graph" />
          </SelectTrigger>
          <SelectContent>
            {SAMPLE_GRAPHS.map(graph => (
              <SelectItem key={graph.id} value={graph.id}>
                {graph.title}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div>
        <Label htmlFor="date">Date</Label>
        <Input 
          id="date" 
          type="date" 
          value={date}
          onChange={(e) => setDate(e.target.value)}
          required 
        />
      </div>

      <div>
        <Label htmlFor="new-value">New Value</Label>
        <Input 
          id="new-value" 
          type="number" 
          value={newValue} 
          onChange={(e) => setNewValue(e.target.value)} 
          required 
        />
      </div>

      <div>
        <Label htmlFor="description">Description</Label>
        <Textarea 
          id="description" 
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
        />
      </div>

      <div>
        <Label htmlFor="media">Media (Optional)</Label>
        <Input
          id="media"
          type="file"
          accept="image/*,video/*"
          onChange={(e) => {
            const file = e.target.files?.[0]
            if (file) handleMediaUpload(file)
          }}
        />
      </div>

      {media && (
        <div className="mt-4">
          {media.startsWith('data:video') ? (
            <video src={media} className="max-h-[200px]" controls />
          ) : (
            <img src={media} alt="Preview" className="max-h-[200px]" />
          )}
        </div>
      )}

      <Button type="submit">Update Graph</Button>
    </form>
  )
}

