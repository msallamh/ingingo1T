'use client'

import React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from 'recharts'

interface ReadingData {
  book: string
  pages: number
}

interface ReadingGraphProps {
  data: ReadingData[]
}

export function ReadingGraph({ data }: ReadingGraphProps) {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Reading 10 Books about Startups</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data}>
            <XAxis dataKey="book" />
            <YAxis />
            <Tooltip />
            <Bar key="pages" dataKey="pages" fill="#8884d8" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

