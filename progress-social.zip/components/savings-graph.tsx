'use client'

import React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from 'recharts'

interface SavingsData {
  month: string
  amount: number
}

interface SavingsGraphProps {
  data: SavingsData[]
}

export function SavingsGraph({ data }: SavingsGraphProps) {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Personal Savings</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data}>
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip />
            <Line key="amount" type="monotone" dataKey="amount" stroke="#82ca9d" />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

