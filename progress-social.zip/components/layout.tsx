'use client'

import { Home, Search, PlusCircle, User } from 'lucide-react'
import { cn } from "@/lib/utils"
import Link from 'next/link'
import { usePathname } from 'next/navigation'

export function Layout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()

  return (
    <div className="min-h-screen bg-[#ffffff]">
      <div className="mx-auto max-w-2xl pb-20">
        {children}
      </div>
      
      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 border-t bg-white">
        <div className="mx-auto max-w-2xl">
          <nav className="flex items-center justify-around p-4">
            <Link 
              href="/"
              className={cn(
                "flex flex-col items-center gap-1",
                pathname === "/" ? "text-[#946fe4]" : "text-gray-400"
              )}
            >
              <Home className="h-6 w-6" />
            </Link>
            <Link 
              href="/search"
              className={cn(
                "flex flex-col items-center gap-1",
                pathname === "/search" ? "text-[#946fe4]" : "text-gray-400"
              )}
            >
              <Search className="h-6 w-6" />
            </Link>
            <Link 
              href="/new"
              className={cn(
                "flex flex-col items-center gap-1",
                pathname === "/new" ? "text-[#946fe4]" : "text-gray-400"
              )}
            >
              <PlusCircle className="h-6 w-6" />
            </Link>
            <Link 
              href="/profile"
              className={cn(
                "flex flex-col items-center gap-1",
                pathname === "/profile" ? "text-[#946fe4]" : "text-gray-400"
              )}
            >
              <User className="h-6 w-6" />
            </Link>
          </nav>
        </div>
      </div>
    </div>
  )
}

