'use client'

import React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from 'recharts'

interface WeightData {
  date: string
  weight: number
}

interface WeightLossGraphProps {
  data: WeightData[]
}

export function WeightLossGraph({ data }: WeightLossGraphProps) {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Weight Loss Progress</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data}>
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Line key="weight" type="monotone" dataKey="weight" stroke="#8884d8" />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

