'use client'

import { useState } from 'react'
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Heart, MessageCircle, MoreHorizontal, X, Plus } from 'lucide-react'
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, Legend, Tooltip } from "recharts"
import { ChallengeButton } from "./challenge-button"

interface ProgressPoint {
  date: string
  speaking: number
  speakingMilestone?: string
  speakingMedia?: string
  height: number
  heightMedia?: string
  mobility: number
  mobilityMilestone?: string
  mobilityMedia?: string
  shortText: string
  note?: string
}

interface MultiProgressBabyCardProps {
  user: {
    name: string
    avatar: string
    handle: string
  }
  title: string
  progress: ProgressPoint[]
  likes: number
  comments: number
  timestamp: string
}

const METRICS = {
  speaking: { color: "#8884d8", label: "Learning to Speak", milestones: ["First word", "First curse word", "First full song recitation"] },
  height: { color: "#ffc658", label: "Growing Up (cm)" },
  mobility: { color: "#ff7300", label: "Walking & Running" }
} as const;

export function MultiProgressBabyCard({
  user,
  title,
  progress: initialProgress,
  likes,
  comments,
  timestamp,
}: MultiProgressBabyCardProps) {
  const [progress, setProgress] = useState(initialProgress)
  const [hoveredPoint, setHoveredPoint] = useState<{ data: ProgressPoint, metric: keyof typeof METRICS } | null>(null)
  const [showAddMilestone, setShowAddMilestone] = useState(false)
  const [newMilestone, setNewMilestone] = useState({
    date: '',
    metric: '',
    value: '',
    media: null as File | null,
  })

const renderDot = (props: any) => {
  const { cx, cy, payload, dataKey } = props
  const metric = METRICS[dataKey as keyof typeof METRICS]
  
  // If the metric doesn't exist in METRICS, return null
  if (!metric) return null

  const hasMedia = payload[`${dataKey}Media`]
  const hasMilestone = payload[`${dataKey}Milestone`]
  const value = dataKey === 'height' ? payload[dataKey] : payload[dataKey]
  
  return (
    <g key={`dot-${dataKey}-${payload.date}`}>
      <circle
        cx={cx}
        cy={cy}
        r={hasMilestone ? 6 : 4}
        fill={hasMedia ? metric.color : "white"}
        stroke={metric.color}
        strokeWidth={2}
        style={{ cursor: "pointer" }}
        onClick={() => setHoveredPoint({ data: payload, metric: dataKey })}
      />
      {hasMilestone && (
        <text 
          x={cx} 
          y={cy - 10} 
          textAnchor="middle" 
          fill={metric.color}
          fontSize={12}
        >
          ⭐
        </text>
      )}
      {dataKey === 'speaking' && metric.milestones && metric.milestones.includes(payload[`${dataKey}Milestone`]) && (
        <text 
          x={cx} 
          y={cy - 15} 
          textAnchor="middle" 
          fill={metric.color}
          fontSize={10}
        >
          {payload[`${dataKey}Milestone`]}
        </text>
      )}
    </g>
  )
}

  const handleAddMilestone = () => {
    if (newMilestone.date && newMilestone.metric && newMilestone.value) {
      const updatedProgress = [...progress]
      const existingPointIndex = updatedProgress.findIndex(p => p.date === newMilestone.date)
      
      if (existingPointIndex !== -1) {
        updatedProgress[existingPointIndex] = {
          ...updatedProgress[existingPointIndex],
          [newMilestone.metric]: parseFloat(newMilestone.value),
          [`${newMilestone.metric}Milestone`]: 'New milestone',
          [`${newMilestone.metric}Media`]: newMilestone.media ? URL.createObjectURL(newMilestone.media) : undefined,
        }
      } else {
        const newPoint: ProgressPoint = {
          date: newMilestone.date,
          speaking: 0,
          height: 0,
          mobility: 0,
          shortText: 'New milestone added',
          [newMilestone.metric]: parseFloat(newMilestone.value),
          [`${newMilestone.metric}Milestone`]: 'New milestone',
          [`${newMilestone.metric}Media`]: newMilestone.media ? URL.createObjectURL(newMilestone.media) : undefined,
        }
        updatedProgress.push(newPoint)
      }

      setProgress(updatedProgress.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()))
      setNewMilestone({ date: '', metric: '', value: '', media: null })
      setShowAddMilestone(false)
    }
  }

  return (
    <Card className="w-full max-w-2xl bg-white shadow-lg rounded-lg overflow-hidden">
      <CardHeader className="flex flex-row items-center gap-4 px-6 py-4 bg-gradient-to-r from-purple-100 to-blue-100">
        <Avatar className="h-10 w-10">
          <AvatarImage src={user.avatar} alt={user.name} />
          <AvatarFallback>{user.name[0]}</AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <h3 className="text-sm font-semibold text-gray-800">{user.name}</h3>
          <p className="text-sm text-gray-600">{timestamp}</p>
        </div>
        <Button variant="ghost" size="icon" className="rounded-full">
          <MoreHorizontal className="h-5 w-5" />
        </Button>
      </CardHeader>
      <CardContent className="px-6 py-4">
        <div className="mb-6">
          <div className="h-[400px] w-full bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg p-4">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={progress} margin={{ top: 20, right: 30, left: 20, bottom: 20 }}>
                <XAxis 
                  dataKey="date" 
                  interval={0}
                  tickFormatter={(value) => {
                    const monthAbbreviations = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                    const [month, year] = value.split(' ');
                    const monthIndex = parseInt(month) - 1;
                    return monthIndex >= 0 && monthIndex < 12 ? monthAbbreviations[monthIndex] : '';
                  }}
                  tick={{ fontSize: 12, fill: '#6B7280' }}
                  axisLine={{ stroke: '#E5E7EB' }}
                  tickLine={{ stroke: '#E5E7EB' }}
                />
                <YAxis yAxisId="left" orientation="left" stroke={METRICS.speaking.color} axisLine={false} tickLine={false} />
                <YAxis yAxisId="right" orientation="right" stroke={METRICS.height.color} axisLine={false} tickLine={false} />
                <Tooltip content={<CustomTooltip />} />
                <Legend />
                {Object.entries(METRICS).map(([metric, { color, label }]) => (
                  <Line
                    key={`line-${metric}`}
                    yAxisId={metric === 'height' ? 'right' : 'left'}
                    type="monotone"
                    dataKey={metric === 'height' ? metric : metric}
                    stroke={color}
                    name={label}
                    strokeWidth={2}
                    dot={renderDot}
                    connectNulls
                  />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </div>
          <p className="mt-4 text-sm text-gray-600">{title}</p>
        </div>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" className="gap-2">
              <Heart className="h-4 w-4" />
              {likes}
            </Button>
            <Button variant="ghost" size="sm" className="gap-2">
              <MessageCircle className="h-4 w-4" />
              {comments}
            </Button>
            <ChallengeButton postId="multi-progress-baby-card" />
          </div>
          <Button variant="outline" size="sm" onClick={() => setShowAddMilestone(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add Milestone
          </Button>
        </div>
        {showAddMilestone && (
          <div className="mt-4 p-4 bg-gray-100 rounded-lg">
            <h4 className="text-sm font-semibold mb-2">Add New Milestone</h4>
            <div className="space-y-2">
              <Input
                type="date"
                value={newMilestone.date}
                onChange={(e) => setNewMilestone({ ...newMilestone, date: e.target.value })}
                placeholder="Date"
              />
              <Select value={newMilestone.metric} onValueChange={(value) => setNewMilestone({ ...newMilestone, metric: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select metric" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(METRICS).map(([key, { label }]) => (
                    <SelectItem key={key} value={key}>{label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                type="number"
                value={newMilestone.value}
                onChange={(e) => setNewMilestone({ ...newMilestone, value: e.target.value })}
                placeholder="Value"
              />
              <Input
                type="file"
                onChange={(e) => setNewMilestone({ ...newMilestone, media: e.target.files ? e.target.files[0] : null })}
                accept="image/*,video/*"
              />
              <Button onClick={handleAddMilestone}>Add Milestone</Button>
            </div>
          </div>
        )}
        {hoveredPoint && (
          <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
            <div className="relative bg-white p-4 rounded-lg max-w-md">
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-2 right-2"
                onClick={() => setHoveredPoint(null)}
              >
                <X className="h-4 w-4" />
              </Button>
              <p className="text-lg font-semibold mb-2">{hoveredPoint.data.date}</p>
              <p className="text-sm mb-2">{hoveredPoint.data.shortText}</p>
              {hoveredPoint.data[`${hoveredPoint.metric}Milestone`] && (
                <p className="text-sm font-medium mb-2">
                  Milestone: {hoveredPoint.data[`${hoveredPoint.metric}Milestone`]}
                </p>
              )}
              {hoveredPoint.data[`${hoveredPoint.metric}Media`] && (
                hoveredPoint.data[`${hoveredPoint.metric}Media`]?.endsWith('.mp4') ? (
                  <video 
                    src={hoveredPoint.data[`${hoveredPoint.metric}Media`]} 
                    className="w-full h-auto rounded-md" 
                    autoPlay 
                    muted 
                    loop
                  />
                ) : (
                  <img
                    src={hoveredPoint.data[`${hoveredPoint.metric}Media`]}
                    alt={`Progress on ${hoveredPoint.data.date}`}
                    className="w-full h-auto rounded-md"
                  />
                )
              )}
              {hoveredPoint.data.note && (
                <p className="text-sm text-muted-foreground mt-2">{hoveredPoint.data.note}</p>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-white p-4 rounded shadow-lg border border-gray-200">
        <p className="font-bold">{label}</p>
        {payload.map((entry: any, index: number) => (
          <p key={`item-${index}`} style={{ color: entry.color }}>
            {entry.name}: {entry.value}
          </p>
        ))}
      </div>
    );
  }

  return null;
};

