'use client'

import React, { useState } from 'react'
import { Card, CardContent, CardHeader, CardFooter } from "@/components/ui/card"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Heart, MessageCircle, MoreHorizontal } from 'lucide-react'
import { AchievementsGraph } from './achievements-graph'
import { PuppyGraph } from './puppy-graph'
import { WeightLossGraph } from './weight-loss-graph'
import { ReadingGraph } from './reading-graph'
import { SavingsGraph } from './savings-graph'
import { PythonGraph } from './python-graph'
import { CigarettesGraph } from './cigarettes-graph'
import { FatherGraph } from './father-graph'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from 'recharts'

interface WebGraphProps {
  data: {
    achievements: any[]
    puppy: any[]
    weightLoss: any[]
    reading: any[]
    savings: any[]
    python: any[]
    cigarettes: any[]
    father: any[]
  }
  user: {
    name: string
    avatar: string
    handle: string
  }
  likes: number
  comments: number
  timestamp: string
  onUpdateWeb: (action: 'add' | 'delete', nodeId?: string) => void
}

export function WebGraph({ data, user, likes, comments, timestamp, onUpdateWeb }: WebGraphProps) {
  const [selectedNode, setSelectedNode] = useState<string | null>(null)
  const [hoveredEdge, setHoveredEdge] = useState<{ edge: Edge, x: number, y: number } | null>(null)
  const [isUpdateDialogOpen, setIsUpdateDialogOpen] = useState(false)
  const [updateAction, setUpdateAction] = useState<'add' | 'delete'>('add')
  const [selectedGraph, setSelectedGraph] = useState('')

  const nodes = [
    { id: 'achievements', label: 'Wu Kong Game', x: 290, y: 50 },
    { id: 'puppy', label: 'Raising Puppy', x: 145, y: 145 },
    { id: 'weightLoss', label: 'Weight Loss', x: 435, y: 145 },
    { id: 'reading', label: 'Reading Books', x: 145, y: 435 },
    { id: 'savings', label: 'Personal Savings', x: 435, y: 435 },
    { id: 'python', label: 'Learning Python', x: 50, y: 290 },
    { id: 'cigarettes', label: 'Cutting Cigarettes', x: 530, y: 290 },
    { id: 'father', label: 'Better Father', x: 290, y: 530 },
  ]

  type Edge = {
    from: string
    to: string
    description: string
  }

  const edges: Edge[] = [
    { from: 'achievements', to: 'python', description: 'Game development success motivates deeper Python learning for advanced game mechanics.' },
    { from: 'puppy', to: 'father', description: 'Caring for a puppy teaches patience and responsibility, directly improving parenting skills.' },
    { from: 'weightLoss', to: 'cigarettes', description: 'Focus on physical health naturally leads to quitting smoking for overall well-being.' },
    { from: 'reading', to: 'python', description: 'Reading tech books enhances understanding of programming concepts, boosting Python skills.' },
    { from: 'savings', to: 'father', description: 'Financial stability reduces stress, allowing more quality time and resources for family.' },
    { from: 'python', to: 'savings', description: 'Improved coding skills open up better job opportunities, increasing earning potential.' },
    { from: 'cigarettes', to: 'weightLoss', description: 'Quitting smoking improves lung capacity and energy, making exercise easier and more effective.' },
    { from: 'father', to: 'puppy', description: 'Parenting experience provides valuable insights for nurturing and training a puppy.' },
  ]

  const renderGraph = (id: string) => {
    const graphData = data[id as keyof typeof data]
    const dataKeys = Object.keys(graphData[0] || {}).filter(key => key !== 'date')
    return (
      <ResponsiveContainer width="100%" height={200}>
        <LineChart data={graphData}>
          <XAxis dataKey="date" />
          <YAxis />
          <Tooltip />
          {dataKeys.map((key, index) => (
            <Line
              key={`line-${id}-${key}-${index}`}
              type="monotone"
              dataKey={key}
              stroke={`hsl(${index * 30}, 70%, 50%)`}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    )
  }

  const handleUpdateWeb = () => {
    if (updateAction === 'add' && selectedGraph) {
      onUpdateWeb('add', selectedGraph)
    } else if (updateAction === 'delete' && selectedNode) {
      onUpdateWeb('delete', selectedNode)
    }
    setIsUpdateDialogOpen(false)
  }

  return (
    <Card className="w-full max-w-3xl bg-white shadow-lg rounded-lg overflow-hidden">
      <CardHeader className="flex flex-row items-center gap-4 px-6 py-4 bg-gradient-to-r from-purple-100 to-blue-100">
        <Avatar className="h-10 w-10">
          <AvatarImage src={user.avatar} alt={user.name} />
          <AvatarFallback>{user.name[0]}</AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <h3 className="text-sm font-semibold">{user.name}</h3>
          <p className="text-sm text-muted-foreground">{timestamp}</p>
        </div>
        <Button variant="ghost" size="icon" className="rounded-full">
          <MoreHorizontal className="h-5 w-5" />
        </Button>
      </CardHeader>
      <CardContent className="px-6 py-4">
        <h4 className="text-lg font-semibold mb-4">Life Progress Web</h4>
        <p className="text-sm text-gray-600 mb-4">
          This web visualizes the interconnected aspects of personal growth. Each node represents a key area of life, with links showing how progress in one area can influence others.
        </p>
        <div className="h-[600px] w-full bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg p-4 relative flex items-center justify-center">
          <svg width="580" height="580">
            {edges.map((edge, index) => {
              const fromNode = nodes.find(n => n.id === edge.from)
              const toNode = nodes.find(n => n.id === edge.to)
              return (
                <line
                  key={`edge-${index}`}
                  x1={fromNode?.x}
                  y1={fromNode?.y}
                  x2={toNode?.x}
                  y2={toNode?.y}
                  stroke="#999"
                  strokeWidth="2"
                  onMouseEnter={(e) => {
                    const rect = e.currentTarget.getBoundingClientRect()
                    const x = (rect.left + rect.right) / 2
                    const y = (rect.top + rect.bottom) / 2
                    setHoveredEdge({ edge, x, y })
                  }}
                  onMouseLeave={() => setHoveredEdge(null)}
                  style={{ cursor: 'pointer' }}
                />
              )
            })}
            {hoveredEdge && (
              <foreignObject
                x={hoveredEdge.x - 100}
                y={hoveredEdge.y - 30}
                width="200"
                height="60"
              >
                <div className="bg-white p-2 rounded shadow text-xs">
                  {hoveredEdge.edge.description}
                </div>
              </foreignObject>
            )}
            {nodes.map((node) => (
              <g key={`node-${node.id}`}>
                <circle
                  cx={node.x}
                  cy={node.y}
                  r="20"
                  fill="#8884d8"
                  onMouseEnter={() => setSelectedNode(node.id)}
                  onMouseLeave={() => setSelectedNode(null)}
                />
                <text x={node.x} y={node.y + 30} textAnchor="middle" fontSize="12">
                  {node.label}
                </text>
                {selectedNode === node.id && (
                  <foreignObject key={`graph-${node.id}-${selectedNode}`} x={node.x - 100} y={node.y - 100} width="200" height="200">
                    <div className="bg-white p-2 rounded shadow">
                      {renderGraph(node.id)}
                    </div>
                  </foreignObject>
                )}
                <Dialog key={`dialog-${node.id}`}>
                  <DialogTrigger asChild>
                    <circle
                      cx={node.x}
                      cy={node.y}
                      r="20"
                      fill="transparent"
                      cursor="pointer"
                    />
                  </DialogTrigger>
                  <DialogContent className="max-w-3xl">
                    <DialogHeader>
                      <DialogTitle>{node.label}</DialogTitle>
                    </DialogHeader>
                    {renderGraph(node.id)}
                  </DialogContent>
                </Dialog>
              </g>
            ))}
          </svg>
        </div>
      </CardContent>
      <CardFooter className="flex justify-between items-center px-6 py-4 bg-gray-50">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" className="gap-2">
            <Heart className="h-4 w-4" />
            {likes}
          </Button>
          <Button variant="ghost" size="sm" className="gap-2">
            <MessageCircle className="h-4 w-4" />
            {comments}
          </Button>
        </div>
        <Dialog open={isUpdateDialogOpen} onOpenChange={setIsUpdateDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="outline" size="sm">
              Update Web
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Update Life Progress Web</DialogTitle>
            </DialogHeader>
            <div className="flex flex-col gap-4 py-4">
              <Select onValueChange={(value) => setUpdateAction(value as 'add' | 'delete')}>
                <SelectTrigger>
                  <SelectValue placeholder="Select action" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="add">Add Graph</SelectItem>
                  <SelectItem value="delete">Delete Graph</SelectItem>
                </SelectContent>
              </Select>
              {updateAction === 'add' && (
                <Select onValueChange={setSelectedGraph}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select graph to add" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newGraph1">New Graph 1</SelectItem>
                    <SelectItem value="newGraph2">New Graph 2</SelectItem>
                    <SelectItem value="newGraph3">New Graph 3</SelectItem>
                  </SelectContent>
                </Select>
              )}
              {updateAction === 'delete' && (
                <Select onValueChange={setSelectedNode}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select graph to delete" />
                  </SelectTrigger>
                  <SelectContent>
                    {nodes.map((node) => (
                      <SelectItem key={node.id} value={node.id}>
                        {node.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
            <DialogFooter>
              <Button onClick={handleUpdateWeb}>
                {updateAction === 'add' ? 'Add to Web' : 'Remove from Web'}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardFooter>
    </Card>
  )
}

