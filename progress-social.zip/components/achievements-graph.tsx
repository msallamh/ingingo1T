'use client'

import React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from 'recharts'

interface AchievementsData {
  date: string
  score: number
}

interface AchievementsGraphProps {
  data: AchievementsData[]
}

export function AchievementsGraph({ data }: AchievementsGraphProps) {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Achievements at Wu Kong Game</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={data}>
            <XAxis dataKey="date" />
            <YAxis />
            <Tooltip />
            <Line key="score" type="monotone" dataKey="score" stroke="#8884d8" />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

