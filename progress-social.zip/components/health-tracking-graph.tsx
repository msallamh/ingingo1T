'use client'

import React, { useState } from 'react'
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Heart, MessageCircle, MoreHorizontal, X } from 'lucide-react'
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts'
import { format } from 'date-fns'

interface JoggingData {
  date: string
  distance: number
  duration: number
  description?: string
  media?: string
}

interface HealthTrackingGraphProps {
  user: {
    name: string
    avatar: string
    handle: string
  }
  title: string
  data: JoggingData[]
  likes: number
  comments: number
  timestamp: string
}

export function HealthTrackingGraph({
  user,
  title,
  data,
  likes,
  comments,
  timestamp,
}: HealthTrackingGraphProps) {
  const [localData, setLocalData] = useState<JoggingData[]>(data)
  const [selectedNode, setSelectedNode] = useState<JoggingData | null>(null)
  const [isEditing, setIsEditing] = useState(false)
  const [editedDescription, setEditedDescription] = useState('')
  const [editedMedia, setEditedMedia] = useState<File | null>(null)

  const handleNodeClick = (node: JoggingData) => {
    setSelectedNode(node)
    setEditedDescription(node.description || '')
    setIsEditing(false)
  }

  const handleEdit = () => {
    setIsEditing(true)
  }

  const handleSave = () => {
    if (selectedNode) {
      const updatedData = localData.map(item => 
        item.date === selectedNode.date 
          ? { 
              ...item, 
              description: editedDescription,
              media: editedMedia ? URL.createObjectURL(editedMedia) : item.media 
            } 
          : item
      )
      setLocalData(updatedData)
      setSelectedNode({ ...selectedNode, description: editedDescription, media: editedMedia ? URL.createObjectURL(editedMedia) : selectedNode.media })
      setIsEditing(false)
      setEditedMedia(null)
    }
  }

  const handleClose = () => {
    setSelectedNode(null)
    setIsEditing(false)
    setEditedDescription('')
    setEditedMedia(null)
  }

  return (
    <Card className="w-full max-w-3xl bg-white shadow-lg rounded-lg overflow-hidden">
      <CardHeader className="flex flex-row items-center gap-4 px-6 py-4 bg-gradient-to-r from-blue-100 to-green-100">
        <Avatar className="h-10 w-10">
          <AvatarImage src={user.avatar} alt={user.name} />
          <AvatarFallback>{user.name[0]}</AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <h3 className="text-sm font-semibold">{user.name}</h3>
          <p className="text-sm text-muted-foreground">{timestamp}</p>
        </div>
        <Button variant="ghost" size="icon" className="rounded-full">
          <MoreHorizontal className="h-5 w-5" />
        </Button>
      </CardHeader>
      <CardContent className="px-6 py-4">
        <h4 className="text-lg font-semibold mb-4">{title}</h4>
        <div className="h-[400px] w-full bg-gradient-to-br from-blue-50 to-green-50 rounded-lg p-4">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={localData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tickFormatter={(date) => format(new Date(date), 'MMM dd')}
              />
              <YAxis yAxisId="left" label={{ value: 'Distance (km)', angle: -90, position: 'insideLeft' }} />
              <YAxis yAxisId="right" orientation="right" label={{ value: 'Duration (min)', angle: 90, position: 'insideRight' }} />
              <Tooltip 
                labelFormatter={(date) => format(new Date(date), 'MMMM dd, yyyy')}
                formatter={(value, name) => [value, name === 'distance' ? 'Distance (km)' : 'Duration (min)']}
              />
              <Line yAxisId="left" type="monotone" dataKey="distance" stroke="#8884d8" activeDot={{ onClick: (_, payload) => handleNodeClick(payload.payload as JoggingData) }} />
              <Line yAxisId="right" type="monotone" dataKey="duration" stroke="#82ca9d" activeDot={{ onClick: (_, payload) => handleNodeClick(payload.payload as JoggingData) }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <div className="flex items-center justify-between mt-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" className="gap-2">
              <Heart className="h-4 w-4" />
              {likes}
            </Button>
            <Button variant="ghost" size="sm" className="gap-2">
              <MessageCircle className="h-4 w-4" />
              {comments}
            </Button>
          </div>
        </div>
        {selectedNode && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white p-6 rounded-lg max-w-md w-full">
              <h5 className="text-lg font-semibold mb-2">
                {format(new Date(selectedNode.date), 'MMMM dd, yyyy')}
              </h5>
              <p className="mb-2">Distance: {selectedNode.distance} km</p>
              <p className="mb-4">Duration: {selectedNode.duration} min</p>
              {isEditing ? (
                <>
                  <Textarea
                    value={editedDescription}
                    onChange={(e) => setEditedDescription(e.target.value)}
                    placeholder="Add a description..."
                    className="mb-2"
                  />
                  <Input
                    type="file"
                    onChange={(e) => setEditedMedia(e.target.files ? e.target.files[0] : null)}
                    accept="image/*,video/*"
                    className="mb-2"
                  />
                  <Button onClick={handleSave} className="mr-2">Save</Button>
                </>
              ) : (
                <>
                  <p className="mb-2">{selectedNode.description}</p>
                  {selectedNode.media && (
                    <div className="mb-4">
                      {selectedNode.media.endsWith('.mp4') ? (
                        <video src={selectedNode.media} className="w-full rounded-md" controls />
                      ) : (
                        <img src={selectedNode.media} alt="Jogging activity" className="w-full rounded-md" />
                      )}
                    </div>
                  )}
                  <Button onClick={handleEdit} className="mr-2">Edit</Button>
                </>
              )}
              <Button variant="ghost" onClick={handleClose}>Close</Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

