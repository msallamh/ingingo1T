'use client'

import * as React from 'react'
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Heart, MessageCircle, MoreHorizontal, X, Plus } from 'lucide-react'
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis } from "recharts"
import { useState } from 'react'
import { Input } from "@/components/ui/input"
import { ChallengeButton } from "./challenge-button"

interface WeightProgressPoint {
  date: string
  weight: number
  media?: string
  shortText: string
  note?: string
}

interface WeightLossProgressCardProps {
  user: {
    name: string
    avatar: string
    handle: string
  }
  title: string
  progress: WeightProgressPoint[]
  likes: number
  comments: number
  timestamp: string
}

export function WeightLossProgressCard({
  user,
  title,
  progress,
  likes,
  comments,
  timestamp,
}: WeightLossProgressCardProps) {
  const [hoveredPoint, setHoveredPoint] = React.useState<WeightProgressPoint | null>(null)
  const [beforeNode, setBeforeNode] = React.useState<WeightProgressPoint | null>(null)
  const [afterNode, setAfterNode] = React.useState<WeightProgressPoint | null>(null)
  const [selectingFor, setSelectingFor] = React.useState<'before' | 'after' | null>(null)
  const [showAddMilestone, setShowAddMilestone] = useState(false)
  const [newMilestone, setNewMilestone] = useState({
    date: '',
    weight: '',
    media: null as File | null,
  })

  const handleNodeClick = (node: WeightProgressPoint) => {
    if (selectingFor === 'before') {
      setBeforeNode(node)
      setSelectingFor(null)
    } else if (selectingFor === 'after') {
      setAfterNode(node)
      setSelectingFor(null)
    } else {
      setHoveredPoint(node)
    }
  }

  const handleAddMilestone = () => {
    if (newMilestone.date && newMilestone.weight) {
      const updatedProgress = [...progress]
      const existingPointIndex = updatedProgress.findIndex(p => p.date === newMilestone.date)
      
      if (existingPointIndex !== -1) {
        updatedProgress[existingPointIndex] = {
          ...updatedProgress[existingPointIndex],
          weight: parseFloat(newMilestone.weight),
          media: newMilestone.media ? URL.createObjectURL(newMilestone.media) : undefined,
        }
      } else {
        const newPoint = {
          date: newMilestone.date,
          weight: parseFloat(newMilestone.weight),
          shortText: 'New milestone added',
          media: newMilestone.media ? URL.createObjectURL(newMilestone.media) : undefined,
        }
        updatedProgress.push(newPoint)
      }

      setProgress(updatedProgress.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()))
      setNewMilestone({ date: '', weight: '', media: null })
      setShowAddMilestone(false)
    }
  }

  return (
    <Card className="w-full max-w-2xl bg-white shadow-lg rounded-lg overflow-hidden">
      <CardHeader className="flex flex-row items-center gap-4 px-6 py-4 bg-gradient-to-r from-purple-100 to-blue-100">
        <Avatar className="h-10 w-10">
          <AvatarImage src={user.avatar} alt={user.name} />
          <AvatarFallback>{user.name[0]}</AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <h3 className="text-sm font-semibold">{user.name}</h3>
          <p className="text-sm text-muted-foreground">{timestamp}</p>
        </div>
        <Button variant="ghost" size="icon" className="rounded-full">
          <MoreHorizontal className="h-5 w-5" />
        </Button>
      </CardHeader>
      <CardContent className="px-6">
        <div className="mb-4">
          <div className="flex justify-between mb-2">
            <div 
              className="w-[48%] aspect-square relative rounded-lg overflow-hidden cursor-pointer"
              onClick={() => setSelectingFor('before')}
            >
              {beforeNode && beforeNode.media ? (
                beforeNode.media.endsWith('.mp4') ? (
                  <video src={beforeNode.media} className="object-cover w-full h-full" autoPlay muted loop />
                ) : (
                  <img src={beforeNode.media} alt="Before" className="object-cover w-full h-full" />
                )
              ) : (
                <div className="w-full h-full bg-gray-200 flex items-center justify-center">
                  <span className="text-gray-500">Click to select 'Before' image</span>
                </div>
              )}
              <div className="absolute bottom-2 left-2 bg-black bg-opacity-50 text-white px-2 py-1 text-xs rounded">
                Before
              </div>
            </div>
            <div 
              className="w-[48%] aspect-square relative rounded-lg overflow-hidden cursor-pointer"
              onClick={() => setSelectingFor('after')}
            >
              {afterNode && afterNode.media ? (
                afterNode.media.endsWith('.mp4') ? (
                  <video src={afterNode.media} className="object-cover w-full h-full" autoPlay muted loop />
                ) : (
                  <img src={afterNode.media} alt="After" className="object-cover w-full h-full" />
                )
              ) : (
                <div className="w-full h-full bg-gray-200 flex items-center justify-center">
                  <span className="text-gray-500">Click to select 'After' image</span>
                </div>
              )}
              <div className="absolute bottom-2 right-2 bg-black bg-opacity-50 text-white px-2 py-1 text-xs rounded">
                After
              </div>
            </div>
          </div>
          <p className="mt-4 text-sm">{title}</p>
          <div className="h-[400px] w-full bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg p-4">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart
                data={progress}
                margin={{ top: 5, right: 5, bottom: 5, left: 5 }}
              >
                <XAxis
                  dataKey="date"
                  tick={{ fill: 'rgba(0,0,0,0.5)', fontSize: 12 }}
                  tickLine={{ stroke: 'rgba(0,0,0,0.5)' }}
                />
                <YAxis
                  tick={{ fill: 'rgba(0,0,0,0.5)', fontSize: 12 }}
                  tickLine={{ stroke: 'rgba(0,0,0,0.5)' }}
                  domain={['dataMin - 5', 'dataMax + 5']}
                />
                <Line
                  type="monotone"
                  dataKey="weight"
                  stroke="rgba(99,102,241,0.8)"
                  strokeWidth={3}
                  dot={(props) => {
                    const { cx, cy, payload } = props;
                    const isBefore = beforeNode && beforeNode.date === payload.date;
                    const isAfter = afterNode && afterNode.date === payload.date;
                    return (
                      <circle
                        key={`dot-${payload.date}`}
                        cx={cx}
                        cy={cy}
                        r={isBefore || isAfter ? 6 : 4}
                        fill={isBefore ? "blue" : isAfter ? "green" : "rgba(99,102,241,0.8)"}
                        stroke="white"
                        strokeWidth={2}
                        style={{ cursor: 'pointer' }}
                        onClick={() => handleNodeClick(payload)}
                      />
                    );
                  }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        <div className="flex items-center gap-4 mt-4">
          <Button variant="ghost" size="sm" className="gap-2">
            <Heart className="h-4 w-4" />
            {likes}
          </Button>
          <Button variant="ghost" size="sm" className="gap-2">
            <MessageCircle className="h-4 w-4" />
            {comments}
          </Button>
          <ChallengeButton postId="weight-loss-progress-card" />
          <Button variant="outline" size="sm" onClick={() => setShowAddMilestone(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add Milestone
          </Button>
        </div>
        {showAddMilestone && (
            <div className="mt-4 p-4 bg-gray-100 rounded-lg">
              <h4 className="text-sm font-semibold mb-2">Add New Milestone</h4>
              <div className="space-y-2">
                <Input
                  type="date"
                  value={newMilestone.date}
                  onChange={(e) => setNewMilestone({ ...newMilestone, date: e.target.value })}
                  placeholder="Date"
                />
                <Input
                  type="number"
                  value={newMilestone.weight}
                  onChange={(e) => setNewMilestone({ ...newMilestone, weight: e.target.value })}
                  placeholder="Weight"
                />
                <Input
                  type="file"
                  onChange={(e) => setNewMilestone({ ...newMilestone, media: e.target.files ? e.target.files[0] : null })}
                  accept="image/*,video/*"
                />
                <Button onClick={handleAddMilestone}>Add Milestone</Button>
              </div>
            </div>
          )}
        {hoveredPoint && (
          <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
            <div className="relative bg-white p-4 rounded-lg max-w-md">
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-2 right-2"
                onClick={() => setHoveredPoint(null)}
              >
                <X className="h-4 w-4" />
              </Button>
              <p className="text-lg font-semibold mb-2">{hoveredPoint.date}</p>
              <p className="text-sm mb-2">{hoveredPoint.shortText}</p>
              <div className="text-sm font-medium">Weight: {hoveredPoint.weight} lbs</div>
              {hoveredPoint.media && (
                hoveredPoint.media.endsWith('.mp4') ? (
                  <video 
                    src={hoveredPoint.media} 
                    className="w-full h-auto rounded-md mt-2" 
                    autoPlay 
                    muted 
                    loop
                  />
                ) : (
                  <img
                    src={hoveredPoint.media}
                    alt={`Progress on ${hoveredPoint.date}`}
                    className="w-full h-auto rounded-md mt-2"
                  />
                )
              )}
              {hoveredPoint.note && (
                <p className="text-sm text-muted-foreground mt-2">{hoveredPoint.note}</p>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

