'use client'

import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card } from "@/components/ui/card"
import { Plus, X } from 'lucide-react'
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis } from "recharts"

interface Node {
  id: string
  date: string
  value: number
  description: string
  media?: string
}

interface NewPostFormProps {
  onSubmit: () => void
}

const GRAPH_TYPES = [
  { value: 'line', label: 'Line Graph' },
  { value: 'dual', label: 'Dual Progress' },
  { value: 'triple', label: 'Triple Progress' },
  { value: 'milestone', label: 'Milestone' },
]

const CATEGORIES = [
  { value: 'fitness', label: 'Fitness' },
  { value: 'health', label: 'Health' },
  { value: 'productivity', label: 'Productivity' },
  { value: 'learning', label: 'Learning' },
  { value: 'finance', label: 'Finance' },
]

export function NewPostForm({ onSubmit }: NewPostFormProps) {
  const [category, setCategory] = useState('')
  const [graphType, setGraphType] = useState('')
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [nodes, setNodes] = useState<Node[]>([])
  const [newNode, setNewNode] = useState<Omit<Node, 'id'>>({
    date: '',
    value: 0,
    description: '',
  })

  const handleAddNode = () => {
    if (newNode.date && newNode.description) {
      setNodes([...nodes, { ...newNode, id: Date.now().toString() }])
      setNewNode({ date: '', value: 0, description: '' })
    }
  }

  const handleRemoveNode = (id: string) => {
    setNodes(nodes.filter(node => node.id !== id))
  }

  const handleMediaUpload = (id: string, file: File) => {
    const reader = new FileReader()
    reader.onloadend = () => {
      setNodes(nodes.map(node => 
        node.id === id ? { ...node, media: reader.result as string } : node
      ))
    }
    reader.readAsDataURL(file)
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    onSubmit()
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="bg-white rounded-lg shadow-sm border border-gray-100">
        <div className="p-4 border-b">
          <h2 className="text-lg font-semibold text-[#946fe4]">Create New Project</h2>
        </div>
        
        <div className="p-4 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="category" className="text-sm font-medium text-gray-700">Category</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger id="category" className="mt-1">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {CATEGORIES.map(cat => (
                    <SelectItem key={cat.value} value={cat.value}>
                      {cat.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <Label htmlFor="graph-type" className="text-sm font-medium text-gray-700">Graph Type</Label>
              <Select value={graphType} onValueChange={setGraphType}>
                <SelectTrigger id="graph-type" className="mt-1">
                  <SelectValue placeholder="Select graph type" />
                </SelectTrigger>
                <SelectContent>
                  {GRAPH_TYPES.map(type => (
                    <SelectItem key={type.value} value={type.value}>
                      {type.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="title" className="text-sm font-medium text-gray-700">Title</Label>
            <Input 
              id="title" 
              value={title} 
              onChange={(e) => setTitle(e.target.value)} 
              className="mt-1"
              required 
            />
          </div>

          <div>
            <Label htmlFor="description" className="text-sm font-medium text-gray-700">Description</Label>
            <Textarea 
              id="description" 
              value={description} 
              onChange={(e) => setDescription(e.target.value)} 
              className="mt-1"
              required 
            />
          </div>

          <div className="border rounded-lg p-4 bg-gray-50">
            <h3 className="text-sm font-semibold mb-4">Add Data Point</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="node-date">Date</Label>
                <Input 
                  id="node-date" 
                  type="date" 
                  value={newNode.date}
                  onChange={(e) => setNewNode({ ...newNode, date: e.target.value })}
                  className="mt-1"
                />
              </div>
              <div>
                <Label htmlFor="node-value">Value</Label>
                <Input 
                  id="node-value" 
                  type="number" 
                  value={newNode.value}
                  onChange={(e) => setNewNode({ ...newNode, value: Number(e.target.value) })}
                  className="mt-1"
                />
              </div>
            </div>
            <div className="mt-4">
              <Label htmlFor="node-description">Description</Label>
              <Textarea 
                id="node-description" 
                value={newNode.description}
                onChange={(e) => setNewNode({ ...newNode, description: e.target.value })}
                className="mt-1"
              />
            </div>
            <Button 
              type="button" 
              onClick={handleAddNode}
              className="mt-4 bg-[#946fe4] text-white hover:bg-[#946fe4]/90"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Data Point
            </Button>
          </div>

          {nodes.length > 0 && (
            <div className="space-y-4">
              <h3 className="text-sm font-semibold">Preview</h3>
              <div className="h-[200px] w-full bg-gray-50 rounded-lg p-4">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={nodes}>
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Line
                      type="monotone"
                      dataKey="value"
                      stroke="#946fe4"
                      strokeWidth={2}
                      dot={true}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>
              
              <div className="space-y-4">
                {nodes.map((node) => (
                  <Card key={node.id} className="p-4">
                    <div className="flex justify-between items-start">
                      <div className="space-y-2">
                        <p className="font-medium">Date: {node.date}</p>
                        <p>Value: {node.value}</p>
                        <p className="text-sm text-gray-600">{node.description}</p>
                      </div>
                      <div className="flex gap-2">
                        <Input
                          type="file"
                          accept="image/*,video/*"
                          onChange={(e) => {
                            const file = e.target.files?.[0]
                            if (file) handleMediaUpload(node.id, file)
                          }}
                          className="max-w-[200px]"
                        />
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => handleRemoveNode(node.id)}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                    {node.media && (
                      <div className="mt-2">
                        {node.media.startsWith('data:video') ? (
                          <video src={node.media} className="max-h-[200px]" controls />
                        ) : (
                          <img src={node.media} alt="Node media" className="max-h-[200px]" />
                        )}
                      </div>
                    )}
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="p-4 border-t bg-gray-50">
          <Button 
            type="submit" 
            className="w-full bg-[#946fe4] text-white hover:bg-[#946fe4]/90"
            disabled={nodes.length === 0}
          >
            Create Project
          </Button>
        </div>
      </div>
    </form>
  )
}

