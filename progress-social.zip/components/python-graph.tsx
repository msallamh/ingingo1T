'use client'

import React from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from 'recharts'

interface PythonData {
  skill: string
  level: number
}

interface PythonGraphProps {
  data: PythonData[]
}

export function PythonGraph({ data }: PythonGraphProps) {
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Learning Python</CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={data}>
            <XAxis dataKey="skill" />
            <YAxis />
            <Tooltip />
            <Bar key="level" dataKey="level" fill="#8884d8" />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  )
}

