'use client'

import { useState } from 'react'
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Heart, MessageCircle, MoreHorizontal } from 'lucide-react'
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, Tooltip, Legend } from "recharts"
import { Progress } from "@/components/ui/progress"

interface IncomeDataPoint {
  date: string
  income: number
  milestone?: string
}

interface ChallengePostProps {
  challenger: {
    name: string
    avatar: string
    age: number
  }
  challenged: {
    name: string
    avatar: string
  }
  challengerData: IncomeDataPoint[]
  challengedData: IncomeDataPoint[]
  likes: number
  comments: number
  timestamp: string
}

export function IncomeChallengePost({
  challenger,
  challenged,
  challengerData,
  challengedData,
  likes,
  comments,
  timestamp,
}: ChallengePostProps) {
  const [votes, setVotes] = useState({ challenger: 0, challenged: 0 })

  const handleVote = (voteFor: 'challenger' | 'challenged') => {
    setVotes(prev => ({
      ...prev,
      [voteFor]: prev[voteFor] + 1
    }))
  }

  const totalVotes = votes.challenger + votes.challenged
  const challengerPercentage = totalVotes > 0 ? (votes.challenger / totalVotes) * 100 : 50

  const renderChart = (data: IncomeDataPoint[], color: string) => (
    <ResponsiveContainer width="100%" height={200}>
      <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
        <XAxis dataKey="date" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Line type="monotone" dataKey="income" stroke={color} strokeWidth={2} />
      </LineChart>
    </ResponsiveContainer>
  )

  return (
    <Card className="w-full max-w-3xl bg-white shadow-lg rounded-lg overflow-hidden">
      <CardHeader className="flex flex-row items-center gap-4 px-6 py-4 bg-gradient-to-r from-purple-100 to-blue-100">
        <Avatar className="h-10 w-10">
          <AvatarImage src={challenger.avatar} alt={challenger.name} />
          <AvatarFallback>{challenger.name[0]}</AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <h3 className="text-sm font-semibold">{challenger.name}</h3>
          <p className="text-sm text-muted-foreground">{timestamp}</p>
        </div>
        <Button variant="ghost" size="icon" className="rounded-full">
          <MoreHorizontal className="h-5 w-5" />
        </Button>
      </CardHeader>
      <CardContent className="p-6">
        <p className="text-sm mb-4">
          Hey everyone! I'm {challenger.age} and I want to challenge myself to increase my monthly income. 
          I'm putting myself up against {challenged.name} to stay motivated. Check out our progress and vote for who you think is doing better!
        </p>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <h4 className="font-semibold mb-2">My Progress</h4>
            {renderChart(challengerData, "#8884d8")}
            <ul className="mt-2 text-sm">
              {challengerData.filter(d => d.milestone).map((d, i) => (
                <li key={i} className="mb-1">
                  {d.date}: {d.milestone}
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-2">{challenged.name}'s Progress</h4>
            {renderChart(challengedData, "#82ca9d")}
            <ul className="mt-2 text-sm">
              {challengedData.filter(d => d.milestone).map((d, i) => (
                <li key={i} className="mb-1">
                  {d.date}: {d.milestone}
                </li>
              ))}
            </ul>
          </div>
        </div>
        <div className="mb-4">
          <h4 className="font-semibold mb-2">Who's doing better?</h4>
          <div className="flex items-center gap-2 mb-2">
            <Progress value={challengerPercentage} className="flex-1" />
            <span className="text-sm font-medium">{votes.challenger}</span>
          </div>
          <div className="flex justify-between">
            <Button onClick={() => handleVote('challenger')} variant="outline" size="sm">
              Vote for me
            </Button>
            <Button onClick={() => handleVote('challenged')} variant="outline" size="sm">
              Vote for {challenged.name}
            </Button>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" className="gap-2">
            <Heart className="h-4 w-4" />
            {likes}
          </Button>
          <Button variant="ghost" size="sm" className="gap-2">
            <MessageCircle className="h-4 w-4" />
            {comments}
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

export const incomeChallengeData: ChallengePostProps = {
  challenger: {
    name: "Alex Thompson",
    avatar: "/placeholder.svg",
    age: 17
  },
  challenged: {
    name: "Sarah Lee",
    avatar: "/placeholder.svg"
  },
  challengerData: [
    { date: "Jan", income: 100, milestone: "Started my first online gig" },
    { date: "Feb", income: 150 },
    { date: "Mar", income: 200, milestone: "Landed a regular client" },
    { date: "Apr", income: 180 },
    { date: "May", income: 250, milestone: "Learned a new skill" },
    { date: "Jun", income: 300 }
  ],
  challengedData: [
    { date: "Jan", income: 2000 },
    { date: "Feb", income: 2200, milestone: "Launched a new product" },
    { date: "Mar", income: 2500 },
    { date: "Apr", income: 3000, milestone: "Secured a big contract" },
    { date: "May", income: 3500 },
    { date: "Jun", income: 4000, milestone: "Hired first employee" }
  ],
  likes: 42,
  comments: 15,
  timestamp: "2 hours ago"
}

