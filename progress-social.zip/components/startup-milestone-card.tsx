'use client'

import React, { useState } from 'react'
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Heart, MessageCircle, MoreHorizontal, Plus, X } from 'lucide-react'
import { BarChart, Bar, XAxis, YAxis, ResponsiveContainer, Tooltip, Cell, LabelList } from 'recharts'
import { ChallengeButton } from "./challenge-button"
import { Input } from "@/components/ui/input"

interface Milestone {
  date: string
  satisfaction: number
  description: string
  media?: string
  shortText: string
  activity: string
}

interface StartupMilestoneCardProps {
  user: {
    name: string
    avatar: string
    handle: string
  }
  title: string
  milestones: Milestone[]
  likes: number
  comments: number
  timestamp: string
}

export function StartupMilestoneCard({
  user,
  title,
  milestones,
  likes,
  comments,
  timestamp,
}: StartupMilestoneCardProps) {
  const [localMilestones, setLocalMilestones] = React.useState<Milestone[]>([
    { date: "2023-01-15", satisfaction: 8, description: "Idea validation", shortText: "Validated our concept", media: "/placeholder.svg", activity: "Business Planning" },
    { date: "2023-01-15", satisfaction: 7, description: "Team building", shortText: "Found a co-founder", activity: "Team" },
    { date: "2023-02-28", satisfaction: 9, description: "MVP development", shortText: "Minimum Viable Product ready", activity: "Product Development" },
    { date: "2023-04-10", satisfaction: 7, description: "First beta user", shortText: "Got our first user!", activity: "User Acquisition" },
    { date: "2023-05-20", satisfaction: 10, description: "Seed funding secured", shortText: "Secured $500K in funding", media: "/placeholder.svg", activity: "Funding" },
    { date: "2023-05-20", satisfaction: 8, description: "New office", shortText: "Moved to a new office", activity: "Operations" },
    { date: "2023-07-01", satisfaction: 9, description: "Public launch", shortText: "We're live!", activity: "Product Launch" },
  ])
  const [hoveredMilestone, setHoveredMilestone] = useState<Milestone | null>(null)
  const [showAddMilestone, setShowAddMilestone] = useState(false)
  const [newMilestone, setNewMilestone] = useState({
    date: '',
    satisfaction: '',
    description: '',
    shortText: '',
    activity: '',
    media: null as File | null,
  })

  const handleAddMilestone = () => {
    if (newMilestone.date && newMilestone.satisfaction && newMilestone.description && newMilestone.activity) {
      const updatedMilestones = [...localMilestones, {
        date: newMilestone.date,
        satisfaction: parseInt(newMilestone.satisfaction),
        description: newMilestone.description,
        shortText: newMilestone.shortText || newMilestone.description.substring(0, 30) + '...',
        activity: newMilestone.activity,
        media: newMilestone.media ? URL.createObjectURL(newMilestone.media) : undefined,
      }]
      setLocalMilestones(updatedMilestones.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()))
      setNewMilestone({ date: '', satisfaction: '', description: '', shortText: '', activity: '', media: null })
      setShowAddMilestone(false)
    }
  }

  const addMilestone = () => {
    const newMilestone: Milestone = {
      date: new Date().toISOString().split('T')[0],
      satisfaction: Math.floor(Math.random() * 10) + 1,
      description: "New milestone",
      shortText: "A new milestone has been added",
      activity: "New Activity",
    }
    setLocalMilestones([...localMilestones, newMilestone])
  }

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-white p-2 border border-gray-200 rounded shadow-md">
          <p className="font-semibold">{data.date}</p>
          <p className="font-medium">{data.activity}</p>
          <p>Satisfaction: {data.satisfaction}/10</p>
          <p>{data.shortText}</p>
        </div>
      );
    }
    return null;
  };

  const getTextWidth = (text, font) => {
    const canvas = document.createElement('canvas');
    const context = canvas.getContext('2d');
    context.font = font;
    return context.measureText(text).width;
  };

  return (
    <Card className="w-full max-w-2xl bg-white shadow-lg rounded-lg overflow-hidden">
      <CardHeader className="flex flex-row items-center gap-4 px-6 py-4 bg-gradient-to-r from-purple-100 to-blue-100">
        <Avatar className="h-10 w-10">
          <AvatarImage src={user.avatar} alt={user.name} />
          <AvatarFallback>{user.name[0]}</AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <h3 className="text-sm font-semibold">{user.name}</h3>
          <p className="text-sm text-muted-foreground">{timestamp}</p>
        </div>
        <Button variant="ghost" size="icon" className="rounded-full">
          <MoreHorizontal className="h-5 w-5" />
        </Button>
      </CardHeader>
      <CardContent className="px-6">
        <div className="mb-4">
          <div className="h-[400px] w-full bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg p-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={localMilestones} margin={{ top: 80, right: 30, bottom: 20, left: 20 }}>
                <XAxis dataKey="date" angle={-45} textAnchor="end" height={80} />
                <YAxis dataKey="satisfaction" domain={[0, 10]} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="satisfaction" fill="#8884d8">
                  {localMilestones.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.media ? "#8884d8" : "#fff"} 
                      stroke="#8884d8" 
                      strokeWidth={2}
                      style={{ cursor: 'pointer' }}
                      onClick={() => setHoveredMilestone(entry)}
                    />
                  ))}
                  <LabelList 
                    dataKey="shortText" 
                    position="top" 
                    angle={0} 
                    fill="hsl(var(--foreground))"
                    fontSize={12}
                    fontFamily="var(--font-sans)"
                    fontWeight="400"
                    offset={10}
                    content={(props) => {
                      const { x, y, width, value } = props;
                      const words = value.split(' ');
                      const lineHeight = 14;
                      const maxWidth = width * 1.5; // Increase the width to allow for more text

                      let lines = [];
                      let line = '';

                      words.forEach(word => {
                        const testLine = line + word + ' ';
                        const testWidth = getTextWidth(testLine, '12px var(--font-sans)');

                        if (testWidth > maxWidth && line !== '') {
                          lines.push(line);
                          line = word + ' ';
                        } else {
                          line = testLine;
                        }
                      });
                      lines.push(line);

                      return (
                        <g>
                          {lines.map((line, i) => (
                            <text
                              key={`line-${i}`}
                              x={x + width / 2}
                              y={y - 10 - (lines.length - 1 - i) * lineHeight}
                              fill="hsl(var(--foreground))"
                              textAnchor="middle"
                              fontSize={12}
                              fontFamily="var(--font-sans)"
                              fontWeight="400"
                            >
                              {line.trim()}
                            </text>
                          ))}
                        </g>
                      );
                    }}
                  />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
        <p className="mt-4 text-sm">{title}</p>
        <div className="flex items-center justify-between gap-4 mt-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" className="gap-2">
              <Heart className="h-4 w-4" />
              {likes}
            </Button>
            <Button variant="ghost" size="sm" className="gap-2">
              <MessageCircle className="h-4 w-4" />
              {comments}
            </Button>
            <ChallengeButton postId="startup-milestone-card" />
          </div>
          <Button variant="outline" size="sm" onClick={() => setShowAddMilestone(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add Milestone
          </Button>
        </div>
        {showAddMilestone && (
          <div className="mt-4 p-4 bg-gray-100 rounded-lg">
            <h4 className="text-sm font-semibold mb-2">Add New Milestone</h4>
            <div className="space-y-2">
              <Input
                type="date"
                value={newMilestone.date}
                onChange={(e) => setNewMilestone({ ...newMilestone, date: e.target.value })}
                placeholder="Date"
              />
              <Input
                type="number"
                value={newMilestone.satisfaction}
                onChange={(e) => setNewMilestone({ ...newMilestone, satisfaction: e.target.value })}
                placeholder="Satisfaction (0-10)"
                min="0"
                max="10"
              />
              <Input
                type="text"
                value={newMilestone.activity}
                onChange={(e) => setNewMilestone({ ...newMilestone, activity: e.target.value })}
                placeholder="Activity"
              />
              <Input
                type="text"
                value={newMilestone.description}
                onChange={(e) => setNewMilestone({ ...newMilestone, description: e.target.value })}
                placeholder="Description"
              />
              <Input
                type="text"
                value={newMilestone.shortText}
                onChange={(e) => setNewMilestone({ ...newMilestone, shortText: e.target.value })}
                placeholder="Short Text (optional)"
              />
              <Input
                type="file"
                onChange={(e) => setNewMilestone({ ...newMilestone, media: e.target.files ? e.target.files[0] : null })}
                accept="image/*,video/*"
              />
              <Button onClick={handleAddMilestone}>Add Milestone</Button>
            </div>
          </div>
        )}
        {hoveredMilestone && (
          <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
            <div className="relative bg-white p-4 rounded-lg max-w-md">
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-2 right-2"
                onClick={() => setHoveredMilestone(null)}
              >
                <X className="h-4 w-4" />
              </Button>
              <p className="text-lg font-semibold mb-2">{hoveredMilestone.date}</p>
              <p className="text-md font-medium mb-2">{hoveredMilestone.activity}</p>
              <p className="text-sm mb-2">{hoveredMilestone.shortText}</p>
              <p className="text-sm font-medium mb-2">Satisfaction: {hoveredMilestone.satisfaction}/10</p>
              {hoveredMilestone.media && (
                <div className="mb-2">
                  {hoveredMilestone.media.endsWith('.mp4') ? (
                    <video 
                      src={hoveredMilestone.media} 
                      className="w-full h-auto rounded-md" 
                      autoPlay 
                      muted 
                      loop
                    />
                  ) : (
                    <img
                      src={hoveredMilestone.media}
                      alt={`Milestone on ${hoveredMilestone.date}`}
                      className="w-full h-auto rounded-md"
                    />
                  )}
                </div>
              )}
              <p className="text-sm mt-2">{hoveredMilestone.description}</p>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

