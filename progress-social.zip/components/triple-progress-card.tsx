'use client'

import React, { useState } from 'react'
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Heart, MessageCircle, MoreHorizontal, X, Plus } from 'lucide-react'
import { Line, LineChart, ResponsiveContainer, XAxis, YAxis, Legend } from "recharts"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ChallengeButton } from "./challenge-button"

interface ProgressPoint {
  date: string
  practice: number
  anger: number
  prayer: number
  practiceMedia?: string
  angerMedia?: string
  prayerMedia?: string
  practiceShortText: string
  angerShortText: string
  prayerShortText: string
  note?: string
}

interface TripleProgressCardProps {
  user: {
    name: string
    avatar: string
    handle: string
  }
  title: string
  progress: ProgressPoint[]
  likes: number
  comments: number
  timestamp: string
}

const colors = {
  practice: "#8884d8",
  anger: "#82ca9d",
  prayer: "#ffc658"
}

export function TripleProgressCard({
  user,
  title,
  progress,
  likes,
  comments,
  timestamp,
}: TripleProgressCardProps) {
  const [hoveredPoint, setHoveredPoint] = useState<{ data: ProgressPoint, dataKey: string } | null>(null)
  const [showAddMilestone, setShowAddMilestone] = useState(false)
  const [newMilestone, setNewMilestone] = useState({
    date: '',
    type: '',
    value: '',
    media: null as File | null,
  })

  const handleAddMilestone = () => {
    if (newMilestone.date && newMilestone.type && newMilestone.value) {
      const updatedProgress = [...progress]
      const existingPointIndex = updatedProgress.findIndex(p => p.date === newMilestone.date)
      
      if (existingPointIndex !== -1) {
        updatedProgress[existingPointIndex] = {
          ...updatedProgress[existingPointIndex],
          [newMilestone.type]: parseFloat(newMilestone.value),
          [`${newMilestone.type}Media`]: newMilestone.media ? URL.createObjectURL(newMilestone.media) : undefined,
        }
      } else {
        const newPoint = {
          date: newMilestone.date,
          practice: newMilestone.type === 'practice' ? parseFloat(newMilestone.value) : 0,
          anger: newMilestone.type === 'anger' ? parseFloat(newMilestone.value) : 0,
          prayer: newMilestone.type === 'prayer' ? parseFloat(newMilestone.value) : 0,
          [`${newMilestone.type}ShortText`]: `New ${newMilestone.type} milestone`,
          [`${newMilestone.type}Media`]: newMilestone.media ? URL.createObjectURL(newMilestone.media) : undefined,
        }
        updatedProgress.push(newPoint)
      }

      setProgress(updatedProgress.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()))
      setNewMilestone({ date: '', type: '', value: '', media: null })
      setShowAddMilestone(false)
    }
  }

  const renderDot = (props: any) => {
    const { cx, cy, payload, dataKey, index } = props;
    return (
      <g key={`dot-${dataKey}-${index}`}>
        <circle
          cx={cx}
          cy={cy}
          r={4}
          fill={payload[`${dataKey}Media`] ? colors[dataKey as keyof typeof colors] : "white"}
          stroke={colors[dataKey as keyof typeof colors]}
          strokeWidth={2}
          style={{ cursor: 'pointer' }}
          onClick={() => setHoveredPoint({ data: payload, dataKey })}
        />
        {dataKey === 'practice' && payload[dataKey] >= 10 && (
          <text 
            x={cx} 
            y={cy - 10} 
            textAnchor="middle" 
            fill={colors[dataKey as keyof typeof colors]} 
            fontSize={12}
          >
            ✓
          </text>
        )}
      </g>
    );
  };

  return (
    <Card className="w-full max-w-2xl bg-white shadow-lg rounded-lg overflow-hidden">
      <CardHeader className="flex flex-row items-center gap-4 px-6 py-4 bg-gradient-to-r from-purple-100 to-blue-100">
        <Avatar className="h-10 w-10">
          <AvatarImage src={user.avatar} alt={user.name} />
          <AvatarFallback>{user.name[0]}</AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <h3 className="text-sm font-semibold">{user.name}</h3>
          <p className="text-sm text-muted-foreground">{timestamp}</p>
        </div>
        <Button variant="ghost" size="icon" className="rounded-full">
          <MoreHorizontal className="h-5 w-5" />
        </Button>
      </CardHeader>
      <CardContent className="px-6">
        <div className="mb-4">
          <div className="h-[400px] w-full bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg p-4">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={progress} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                <XAxis dataKey="date" />
                <YAxis />
                <Legend />
                {(['practice', 'anger', 'prayer'] as const).map((dataKey) => (
                  <Line
                    key={dataKey}
                    type="monotone"
                    dataKey={dataKey}
                    stroke={colors[dataKey]}
                    name={dataKey.charAt(0).toUpperCase() + dataKey.slice(1)}
                    strokeWidth={2}
                    dot={renderDot}
                    isAnimationActive={false}
                  />
                ))}
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
        <p className="mt-4 text-sm">{title}</p>
        <div className="flex items-center gap-4 mt-4">
          <Button variant="ghost" size="sm" className="gap-2">
            <Heart className="h-4 w-4" />
            {likes}
          </Button>
          <Button variant="ghost" size="sm" className="gap-2">
            <MessageCircle className="h-4 w-4" />
            {comments}
          </Button>
          <ChallengeButton postId="triple-progress-card" />
          <Button variant="outline" size="sm" onClick={() => setShowAddMilestone(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Add Milestone
          </Button>
        </div>
        {showAddMilestone && (
          <div className="mt-4 p-4 bg-gray-100 rounded-lg">
            <h4 className="text-sm font-semibold mb-2">Add New Milestone</h4>
            <div className="space-y-2">
              <Input
                type="date"
                value={newMilestone.date}
                onChange={(e) => setNewMilestone({ ...newMilestone, date: e.target.value })}
                placeholder="Date"
              />
              <Select value={newMilestone.type} onValueChange={(value) => setNewMilestone({ ...newMilestone, type: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="practice">Practice</SelectItem>
                  <SelectItem value="anger">Anger</SelectItem>
                  <SelectItem value="prayer">Prayer</SelectItem>
                </SelectContent>
              </Select>
              <Input
                type="number"
                value={newMilestone.value}
                onChange={(e) => setNewMilestone({ ...newMilestone, value: e.target.value })}
                placeholder="Value"
              />
              <Input
                type="file"
                onChange={(e) => setNewMilestone({ ...newMilestone, media: e.target.files ? e.target.files[0] : null })}
                accept="image/*,video/*"
              />
              <Button onClick={handleAddMilestone}>Add Milestone</Button>
            </div>
          </div>
        )}
        {hoveredPoint && hoveredPoint.data[`${hoveredPoint.dataKey}Media`] && (
          <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
            <div className="relative bg-white p-4 rounded-lg max-w-md">
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-2 right-2"
                onClick={() => setHoveredPoint(null)}
              >
                <X className="h-4 w-4" />
              </Button>
              <p className="text-lg font-semibold mb-2">{hoveredPoint.data.date}</p>
              <p className="text-sm mb-2">{hoveredPoint.data[`${hoveredPoint.dataKey}ShortText`]}</p>
              {hoveredPoint.data[`${hoveredPoint.dataKey}Media`].endsWith('.mp4') ? (
                <video 
                  src={hoveredPoint.data[`${hoveredPoint.dataKey}Media`]} 
                  className="w-full h-auto rounded-md" 
                  autoPlay 
                  muted 
                  loop
                />
              ) : (
                <img
                  src={hoveredPoint.data[`${hoveredPoint.dataKey}Media`]}
                  alt={`${hoveredPoint.dataKey} progress on ${hoveredPoint.data.date}`}
                  className="w-full h-auto rounded-md"
                />
              )}
              {hoveredPoint.data.note && (
                <p className="text-sm text-muted-foreground mt-2">{hoveredPoint.data.note}</p>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}

