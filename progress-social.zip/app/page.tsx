'use client'

import { useState } from 'react'
import { Button } from "@/components/ui/button"
import { NewPostForm } from "@/components/new-post-form"
import { UpdateGraphForm } from "@/components/update-graph-form"
import { ChallengeButton } from "@/components/challenge-button"
import { DualProgressCard } from "@/components/dual-progress-card"
import { WeightLossProgressCard } from "@/components/weight-loss-progress-card"
import { TripleProgressCard } from "@/components/triple-progress-card"
import { StartupMilestoneCard } from "@/components/startup-milestone-card"
import { MultiProgressBabyCard } from "@/components/multi-progress-baby-card"
import { IncomeChallengePost, incomeChallengeData } from "@/components/income-challenge-post"
import { HealthTrackingGraph } from "@/components/health-tracking-graph"
import { PianoLearningGraph } from "@/components/piano-learning-graph"
import { SpotifyListenersGraph } from "@/components/spotify-listeners-graph"
import { ConsistentPracticeGraph } from "@/components/consistent-practice-graph"
import { DepressionTrackingGraph } from "@/components/depression-tracking-graph"
import { WebGraph } from '@/components/web-graph'
import { Layout } from '@/components/layout'

const DUAL_PROGRESS_DATA = {
  user: {
    name: "Sarah Johnson",
    avatar: "/placeholder.svg",
    handle: "@sarahjohnson",
  },
  title: "Quitting smoking and getting fit! 🚭🏋️‍♀️",
  progress: [
    { date: "Nov 1", smoking: 20, exercise: 10, smokingShortText: "Last day of smoking", exerciseShortText: "First workout", note: "Day 1 of my journey" },
    { date: "Nov 2", smoking: 15, exercise: 20, smokingMedia: "/placeholder.svg", smokingShortText: "Cutting down", exerciseShortText: "Doubled my exercise", note: "Feeling motivated" },
    { date: "Nov 3", smoking: 10, exercise: 30, exerciseMedia: "/placeholder.svg", smokingShortText: "Half way there", exerciseShortText: "Pushing harder", note: "Making progress" },
    { date: "Nov 4", smoking: 5, exercise: 45, smokingMedia: "/placeholder.svg", exerciseMedia: "/placeholder.svg", smokingShortText: "Almost quit", exerciseShortText: "New record", note: "Proud of myself!" },
    { date: "Nov 5", smoking: 3, exercise: 60, smokingShortText: "Final push", exerciseShortText: "Feeling great", note: "Almost there!" },
  ],
  likes: 78,
  comments: 12,
  timestamp: "5 min ago",
}

const WEIGHT_LOSS_DATA = {
  user: {
    name: "Emily Rodriguez",
    avatar: "/placeholder.svg",
    handle: "@emilyrod",
  },
  title: "My weight loss journey - 3 months progress! 🏋️‍♀️🥗",
  progress: [
    { date: "Week 1", weight: 180, shortText: "Starting point" },
    { date: "Week 2", weight: 178, shortText: "Small progress" },
    { date: "Week 3", weight: 176, media: "/placeholder.svg?height=200&width=200", shortText: "Feeling good" },
    { date: "Week 4", weight: 174, shortText: "Steady progress" },
    { date: "Week 5", weight: 171, shortText: "Big drop this week" },
    { date: "Week 6", weight: 169, media: "/placeholder.svg?height=200&width=200", shortText: "Halfway point" },
    { date: "Week 7", weight: 167, shortText: "Keeping it up" },
    { date: "Week 8", weight: 165, shortText: "Two months in" },
    { date: "Week 9", weight: 163, media: "/placeholder.svg?height=200&width=200", shortText: "New milestone" },
    { date: "Week 10", weight: 161, shortText: "Almost there" },
    { date: "Week 11", weight: 159, shortText: "So close" },
    { date: "Week 12", weight: 157, media: "/placeholder.svg?height=200&width=200", shortText: "Final result" },
  ],
  likes: 156,
  comments: 23,
  timestamp: "2 min ago",
}

const TRIPLE_PROGRESS_DATA = {
  user: {
    name: "Michael Brown",
    avatar: "/placeholder.svg",
    handle: "@michaelbrown",
  },
  title: "My journey of self-improvement 🌟",
  progress: [
    { date: "Week 1", practice: 5, anger: 7, prayer: 3, practiceShortText: "Started practice", angerShortText: "High anger", prayerShortText: "Few prayers" },
    { date: "Week 2", practice: 7, anger: 6, prayer: 4, practiceShortText: "Improving", angerShortText: "Slight improvement", prayerShortText: "More consistent", practiceMedia: "/placeholder.svg" },
    { date: "Week 3", practice: 8, anger: 5, prayer: 4, practiceShortText: "Getting better", angerShortText: "Managing better", prayerShortText: "Maintaining" },
    { date: "Week 4", practice: 10, anger: 4, prayer: 5, practiceShortText: "Perfect week", angerShortText: "Much calmer", prayerShortText: "All 5 prayers", angerMedia: "/placeholder.svg" },
    { date: "Week 5", practice: 10, anger: 3, prayer: 5, practiceShortText: "Consistent", angerShortText: "Rarely angry", prayerShortText: "Consistent prayers" },
    { date: "Week 6", practice: 10, anger: 2, prayer: 5, practiceShortText: "Maintaining", angerShortText: "Zen master", prayerShortText: "Spiritual growth", prayerMedia: "/placeholder.svg" },
  ],
  likes: 89,
  comments: 15,
  timestamp: "1 hour ago",
}

const STARTUP_MILESTONE_DATA = {
  user: {
    name: "Sophia Lee",
    avatar: "/placeholder.svg",
    handle: "@sophialee",
  },
  title: "Building my tech startup: Key milestones 🚀",
  milestones: [
    { date: "2023-01-15", satisfaction: 8, description: "Idea validation", shortText: "Validated our concept", media: "/placeholder.svg", activity: "Business Planning" },
    { date: "2023-01-15", satisfaction: 7, description: "Team building", shortText: "Found a co-founder", activity: "Team" },
    { date: "2023-02-28", satisfaction: 9, description: "MVP development", shortText: "Minimum Viable Product ready", activity: "Product Development" },
    { date: "2023-04-10", satisfaction: 7, description: "First beta user", shortText: "Got our first user!", activity: "User Acquisition" },
    { date: "2023-05-20", satisfaction: 10, description: "Seed funding secured", shortText: "Secured $500K in funding", media: "/placeholder.svg", activity: "Funding" },
    { date: "2023-05-20", satisfaction: 8, description: "New office", shortText: "Moved to a new office", activity: "Operations" },
    { date: "2023-07-01", satisfaction: 9, description: "Public launch", shortText: "We're live!", activity: "Product Launch" },
  ],
  likes: 132,
  comments: 28,
  timestamp: "3 hours ago",
}

const BABY_PROGRESS_DATA = {
  user: {
    name: "Sarah Miller",
    avatar: "/placeholder.svg",
    handle: "@sarahmiller",
  },
  title: "My son Bobby is growing up fast)) i feel so blessed, here is his progress in a couple of areas that im tracking",
  progress: [
    ...[...Array(18)].map((_, i) => {
      const months = (i + 1) * 2;
      return {
        date: `${months} months`,
        speaking: Math.min(10, Math.floor(months / 3)),
        speakingMilestone: months === 12 ? "First word" : months === 24 ? "Short sentences" : undefined,
        speakingMedia: months % 6 === 0 ? "/placeholder.svg" : undefined,
        height: 50 + Math.floor(months * 0.8),
        heightMedia: months % 4 === 0 ? "/placeholder.svg" : undefined,
        mobility: Math.min(10, Math.floor(months / 3)),
        mobilityMilestone: months === 12 ? "First steps" : months === 24 ? "Running" : undefined,
        mobilityMedia: months % 6 === 0 ? "/placeholder.svg" : undefined,
        shortText: `${months} month checkup`,
        note: months % 6 === 0 ? `Major milestone at ${months} months!` : undefined,
      };
    }),
  ],
  likes: 245,
  comments: 32,
  timestamp: "2 hours ago",
}

const HEALTH_TRACKING_DATA = {
  user: {
    name: "John Doe",
    avatar: "/placeholder.svg",
    handle: "@johndoe",
  },
  title: "My Daily Jogging Progress",
  data: [
    { date: '2023-07-01', distance: 3.2, duration: 25 },
    { date: '2023-07-02', distance: 4.1, duration: 32, media: '/placeholder.svg' },
    { date: '2023-07-03', distance: 3.8, duration: 30 },
    { date: '2023-07-04', distance: 5.0, duration: 40, description: 'Felt great today!', media: '/placeholder.svg' },
    { date: '2023-07-05', distance: 3.5, duration: 28 },
    { date: '2023-07-06', distance: 4.3, duration: 35 },
    { date: '2023-07-07', distance: 4.7, duration: 38, media: '/placeholder.svg' },
  ],
  likes: 42,
  comments: 7,
  timestamp: "2 hours ago",
}

const PIANO_LEARNING_DATA = {
  user: {
    name: "Jane Smith",
    avatar: "/placeholder.svg",
    handle: "@janesmith",
  },
  title: "My Piano Learning Journey",
  data: [
    { date: '2023-07-01', confidence: 2 },
    { date: '2023-07-08', confidence: 3, description: 'Learned basic chords', media: '/placeholder.svg' },
    { date: '2023-07-15', confidence: 4 },
    { date: '2023-07-22', confidence: 5, description: 'Played my first song!', media: '/placeholder.svg' },
    { date: '2023-07-29', confidence: 6 },
    { date: '2023-08-05', confidence: 7, description: 'Feeling more comfortable with the keys', media: '/placeholder.svg' },
    { date: '2023-08-12', confidence: 8 },
  ],
  likes: 38,
  comments: 5,
  timestamp: "3 hours ago",
}

const SPOTIFY_LISTENERS_DATA = {
  user: {
    name: "Music Artist",
    avatar: "/placeholder.svg",
    handle: "@musicartist",
  },
  title: "My Spotify Monthly Listeners Growth",
  data: [
    { date: '2023-01-01', listeners: 10000 },
    { date: '2023-02-01', listeners: 15000, description: 'Released new single', media: '/placeholder.svg' },
    { date: '2023-03-01', listeners: 20000 },
    { date: '2023-04-01', listeners: 35000, description: 'Featured on popular playlist', media: '/placeholder.svg' },
    { date: '2023-05-01', listeners: 50000 },
    { date: '2023-06-01', listeners: 75000, description: 'Album release', media: '/placeholder.svg' },
    { date: '2023-07-01', listeners: 100000 },
  ],
  likes: 156,
  comments: 23,
  timestamp: "1 day ago",
}

const CONSISTENT_PRACTICE_DATA = {
  user: {
    name: "Practice Master",
    avatar: "/placeholder.svg",
    handle: "@practicemaster",
  },
  title: "My Consistent Practice Journey",
  data: [
    { date: '2023-07-01', consistency: 3 },
    { date: '2023-07-08', consistency: 5, description: 'Started daily practice routine', media: '/placeholder.svg' },
    { date: '2023-07-15', consistency: 6 },
    { date: '2023-07-22', consistency: 7, description: 'Feeling more disciplined', media: '/placeholder.svg' },
    { date: '2023-07-29', consistency: 8 },
    { date: '2023-08-05', consistency: 9, description: 'Almost perfect week!', media: '/placeholder.svg' },
    { date: '2023-08-12', consistency: 10, description: 'Achieved perfect consistency!', media: '/placeholder.svg' },
  ],
  likes: 89,
  comments: 12,
  timestamp: "5 hours ago",
}

const DEPRESSION_TRACKING_DATA = {
  user: {
    name: "Anonymous",
    avatar: "/placeholder.svg",
    handle: "@anonymous",
  },
  title: "My Mood Tracking Journey",
  data: [
    { date: '2023-07-01', mood: 3 },
    { date: '2023-07-08', mood: 4, description: 'Started therapy', media: '/placeholder.svg' },
    { date: '2023-07-15', mood: 3 },
    { date: '2023-07-22', mood: 5, description: 'Good day today', media: '/placeholder.svg' },
    { date: '2023-07-29', mood: 4 },
    {date: '2023-08-05', mood: 6, description: 'Feeling more hopeful', media: '/placeholder.svg' },
    { date: '2023-08-12', mood: 5 },
  ],
  likes: 67,
  comments: 15,
  timestamp: "1 hour ago",
}

const WEB_GRAPH_DATA = {
  achievements: [
    { date: '2023-01', score: 20 },
    { date: '2023-02', score: 35 },
    { date: '2023-03', score: 50 },
    { date: '2023-04', score: 65 },
    { date: '2023-05', score: 80 },
  ],
  puppy: [
    { date: '2023-01', tricks: 1 },
    { date: '2023-02', tricks: 3 },
    { date: '2023-03', tricks: 5 },
    { date: '2023-04', tricks: 7 },
    { date: '2023-05', tricks: 10 },
  ],
  weightLoss: [
    { date: '2023-01', weight: 90 },
    { date: '2023-02', weight: 88 },
    { date: '2023-03', weight: 85 },
    { date: '2023-04', weight: 83 },
    { date: '2023-05', weight: 80 },
  ],
  reading: [
    { book: 'Book 1', pages: 200 },
    { book: 'Book 2', pages: 250 },
    { book: 'Book 3', pages: 180 },
    { book: 'Book 4', pages: 300 },
    { book: 'Book 5', pages: 220 },
  ],
  savings: [
    { month: 'Jan', amount: 500 },
    { month: 'Feb', amount: 750 },
    { month: 'Mar', amount: 1000 },
    { month: 'Apr', amount: 1250 },
    { month: 'May', amount: 1500 },
  ],
  python: [
    { skill: 'Basics', level: 8 },
    { skill: 'OOP', level: 6 },
    { skill: 'Web Dev', level: 4 },
    { skill: 'Data Science', level: 3 },
    { skill: 'Machine Learning', level: 2 },
  ],
  cigarettes: [
    { date: '2023-01', count: 20 },
    { date: '2023-02', count: 15 },
    { date: '2023-03', count: 10 },
    { date: '2023-04', count: 5 },
    { date: '2023-05', count: 2 },
  ],
  father: [
    { attribute: 'Patience', score: 7 },
    { attribute: 'Communication', score: 6 },
    { attribute: 'Quality Time', score: 8 },
    { attribute: 'Support', score: 7 },
    { attribute: 'Understanding', score: 6 },
  ],
}

export default function Home() {
  const [activeView, setActiveView] = useState<'feed' | 'newPost' | 'updateGraph'>('feed')

  return (
    <Layout>
      <header className="sticky top-0 z-40 bg-white border-b">
        <div className="flex items-center justify-between px-4 py-4">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8">
              <svg
                viewBox="0 0 24 24"
                fill="none"
                stroke="#946fe4"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <polygon points="12 2 2 7 12 12 22 7 12 2" />
                <polyline points="2 17 12 22 22 17" />
                <polyline points="2 12 12 17 22 12" />
              </svg>
            </div>
            <h1 className="text-xl font-bold text-[#946fe4]">Feed</h1>
          </div>
          <div className="flex gap-2">
            <Button 
              variant={activeView === 'newPost' ? 'default' : 'outline'} 
              onClick={() => setActiveView('newPost')}
              className="bg-[#946fe4] text-white hover:bg-[#946fe4]/90"
            >
              New Post
            </Button>
            <Button 
              variant={activeView === 'updateGraph' ? 'default' : 'outline'} 
              onClick={() => setActiveView('updateGraph')}
              className="bg-[#946fe4] text-white hover:bg-[#946fe4]/90"
            >
              Update Graph
            </Button>
          </div>
        </div>
      </header>

      <main className="p-4 space-y-4">
        {activeView === 'feed' && (
          <>
            <IncomeChallengePost {...incomeChallengeData} />
            <MultiProgressBabyCard {...BABY_PROGRESS_DATA} />
            <DualProgressCard {...DUAL_PROGRESS_DATA} />
            <WeightLossProgressCard {...WEIGHT_LOSS_DATA} />
            <TripleProgressCard {...TRIPLE_PROGRESS_DATA} />
            <StartupMilestoneCard {...STARTUP_MILESTONE_DATA} />
            <HealthTrackingGraph {...HEALTH_TRACKING_DATA} />
            <PianoLearningGraph {...PIANO_LEARNING_DATA} />
            <SpotifyListenersGraph {...SPOTIFY_LISTENERS_DATA} />
            <ConsistentPracticeGraph {...CONSISTENT_PRACTICE_DATA} />
            <DepressionTrackingGraph {...DEPRESSION_TRACKING_DATA} />
            <WebGraph 
              data={WEB_GRAPH_DATA} 
              user={{
                name: "Life Progress Tracker",
                avatar: "/placeholder.svg",
                handle: "@lifetracker"
              }}
              likes={120}
              comments={15}
              timestamp="1 day ago"
              onUpdateWeb={(action, nodeId) => {
                console.log(`Update web: ${action} ${nodeId}`);
              }}
            />
          </>
        )}
        {activeView === 'newPost' && <NewPostForm onSubmit={() => setActiveView('feed')} />}
        {activeView === 'updateGraph' && <UpdateGraphForm onSubmit={() => setActiveView('feed')} />}
      </main>
    </Layout>
  )
}

